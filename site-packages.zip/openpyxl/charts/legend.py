from __future__ import absolute_import
# Copyright (c) 2010-2015 openpyxl


class Legend(object):

    def __init__(self):

        self.position = 'r'
        self.layout = None
